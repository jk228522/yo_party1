/**
 * App.js
 * Entry point.
 */

import React, { useEffect } from 'react';
import TrackPlayer from 'react-native-track-player';
import AppUI from './src/screens/AppUI';

const App = () => {
  useEffect(() => {
    TrackPlayer.setupPlayer().catch((err) => {
      console.warn('TrackPlayer setup failed', err);
    });
  }, []);

  return ;
};

export default App;