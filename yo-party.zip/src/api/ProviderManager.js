/**
 * ProviderManager.js
 * Central orchestrator for ALL music API providers.
 *
 * - Holds an unlimited list of provider adapters (Jamendo, SoundCloud,
 *   and any number of user-added Generic REST APIs).
 * - Automatically tries providers in priority order and falls back
 *   silently on error — the caller never has to pick a provider.
 * - Persists provider configs (including keys) via AsyncStorage.
 */

import AsyncStorage from '@react-native-async-storage/async-storage';
import JamendoAdapter from './adapters/JamendoAdapter';
import SoundCloudAdapter from './adapters/SoundCloudAdapter';
import GenericRestAdapter from './adapters/GenericRestAdapter';

const STORAGE_KEY = 'YOPARTY_API_PROVIDERS_V1';

const ADAPTER_REGISTRY = {
  jamendo: JamendoAdapter,
  soundcloud: SoundCloudAdapter,
  generic: GenericRestAdapter,
};

class ProviderManager {
  constructor() {
    this.adapters = [];
    this.loaded = false;
  }

  async loadFromStorage() {
    try {
      const raw = await AsyncStorage.getItem(STORAGE_KEY);
      const configs = raw ? JSON.parse(raw) : [];
      this.adapters = configs.map((cfg) => this._instantiate(cfg));
      this.loaded = true;
      return this.adapters;
    } catch (err) {
      console.warn('ProviderManager: failed to load providers from storage', err);
      this.adapters = [];
      this.loaded = true;
      return this.adapters;
    }
  }

  async _persist() {
    const configs = this.adapters.map((a) => ({
      type: a.type,
      id: a.id,
      name: a.name,
      apiKey: a.apiKey,
      baseUrl: a.baseUrl,
      searchPath: a.searchPath,
      responseMap: a.responseMap,
      enabled: a.enabled,
      priority: a.priority,
    }));
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(configs));
  }

  _instantiate(cfg) {
    const AdapterClass = ADAPTER_REGISTRY[cfg.type] || GenericRestAdapter;
    const instance = new AdapterClass(cfg);
    instance.type = cfg.type;
    return instance;
  }

  /**
   * Adds a new provider. type: 'jamendo' | 'soundcloud' | 'generic'
   * Returns the new adapter instance.
   */
  async addProvider(cfg) {
    const id = cfg.id || `${cfg.type}_${Date.now()}_${Math.floor(Math.random() * 1000)}`;
    const adapter = this._instantiate({ ...cfg, id });
    this.adapters.push(adapter);
    await this._persist();
    return adapter;
  }

  async removeProvider(id) {
    this.adapters = this.adapters.filter((a) => a.id !== id);
    await this._persist();
  }

  async setEnabled(id, enabled) {
    const adapter = this.adapters.find((a) => a.id === id);
    if (adapter) {
      adapter.enabled = enabled;
      await this._persist();
    }
  }

  async testProvider(id) {
    const adapter = this.adapters.find((a) => a.id === id);
    if (!adapter) return { ok: false, message: 'Provider not found' };
    return adapter.testConnection();
  }

  getProviders() {
    return this.adapters;
  }

  getActiveProviders() {
    return this.adapters
      .filter((a) => a.isReady())
      .sort((a, b) => b.priority - a.priority);
  }

  /**
   * The key method: searches across ALL enabled, ready providers
   * automatically. No provider needs to be picked manually.
   * Strategy: fire all active providers in parallel, merge every
   * successful result set, and silently skip any that error out.
   */
  async searchAll(query) {
    const active = this.getActiveProviders();
    if (active.length === 0) {
      throw new Error('No active API providers configured. Add an API key to start searching.');
    }

    const results = await Promise.allSettled(active.map((adapter) => adapter.search(query)));

    const merged = [];
    const errors = [];

    results.forEach((result, index) => {
      const adapter = active[index];
      if (result.status === 'fulfilled') {
        merged.push(...result.value);
      } else {
        errors.push({ provider: adapter.name, error: result.reason.message });
      }
    });

    if (merged.length === 0 && errors.length > 0) {
      // All providers failed - surface a combined error instead of a silent empty list
      const summary = errors.map((e) => `${e.provider}: ${e.error}`).join(' | ');
      throw new Error(`All providers failed. ${summary}`);
    }

    return { tracks: merged, partialErrors: errors };
  }
}

// Singleton instance shared across the app
const providerManager = new ProviderManager();
export default providerManager;