/**
 * JamendoAdapter.js
 * Adapter for the Jamendo open-source music API.
 * Docs: https://api.jamendo.com/v3.0/
 */

import BaseAdapter from './BaseAdapter';

class JamendoAdapter extends BaseAdapter {
  constructor(config) {
    super({
      ...config,
      name: config.name || 'Jamendo',
      baseUrl: config.baseUrl || 'https://api.jamendo.com/v3.0',
    });
  }

  async testConnection() {
    try {
      const url = `${this.baseUrl}/tracks/?client_id=${this.apiKey}&format=json&limit=1`;
      const response = await this._fetchWithTimeout(url);
      if (!response.ok) {
        return { ok: false, message: `Jamendo responded with status ${response.status}` };
      }
      const data = await response.json();
      if (data.headers && data.headers.status === 'failed') {
        return { ok: false, message: data.headers.error_message || 'Invalid Jamendo API key' };
      }
      return { ok: true, message: 'Jamendo connected successfully' };
    } catch (err) {
      return { ok: false, message: `Jamendo connection failed: ${err.message}` };
    }
  }

  async search(query) {
    if (!this.isReady()) {
      throw new Error('JamendoAdapter is not ready: missing API key or disabled');
    }
    const url = `${this.baseUrl}/tracks/?client_id=${this.apiKey}&format=json&limit=20&namesearch=${encodeURIComponent(
      query
    )}&include=musicinfo`;

    const response = await this._fetchWithTimeout(url);
    if (!response.ok) {
      throw new Error(`Jamendo search failed with status ${response.status}`);
    }
    const data = await response.json();
    if (!data.results) return [];
    return data.results.map((track) => this.normalizeTrack(track));
  }

  normalizeTrack(raw) {
    return {
      id: `jamendo_${raw.id}`,
      title: raw.name || 'Unknown Title',
      artist: raw.artist_name || 'Unknown Artist',
      albumArt: raw.image || null,
      streamUrl: raw.audio || raw.audiodownload || null,
      duration: raw.duration || 0,
      source: 'Jamendo',
    };
  }

  async _fetchWithTimeout(url) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), this.timeoutMs);
    try {
      return await fetch(url, { signal: controller.signal });
    } finally {
      clearTimeout(timer);
    }
  }
}

export default JamendoAdapter;