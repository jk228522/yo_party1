/**
 * SoundCloudAdapter.js
 * Adapter for SoundCloud's public API (Free Tier).
 * Note: SoundCloud API access requires an approved client_id from SoundCloud.
 */

import BaseAdapter from './BaseAdapter';

class SoundCloudAdapter extends BaseAdapter {
  constructor(config) {
    super({
      ...config,
      name: config.name || 'SoundCloud',
      baseUrl: config.baseUrl || 'https://api-v2.soundcloud.com',
    });
  }

  async testConnection() {
    try {
      const url = `${this.baseUrl}/search/tracks?q=test&client_id=${this.apiKey}&limit=1`;
      const response = await this._fetchWithTimeout(url);
      if (!response.ok) {
        return { ok: false, message: `SoundCloud responded with status ${response.status}` };
      }
      return { ok: true, message: 'SoundCloud connected successfully' };
    } catch (err) {
      return { ok: false, message: `SoundCloud connection failed: ${err.message}` };
    }
  }

  async search(query) {
    if (!this.isReady()) {
      throw new Error('SoundCloudAdapter is not ready: missing API key or disabled');
    }
    const url = `${this.baseUrl}/search/tracks?q=${encodeURIComponent(query)}&client_id=${this.apiKey}&limit=20`;

    const response = await this._fetchWithTimeout(url);
    if (!response.ok) {
      throw new Error(`SoundCloud search failed with status ${response.status}`);
    }
    const data = await response.json();
    if (!data.collection) return [];
    return data.collection.map((track) => this.normalizeTrack(track));
  }

  normalizeTrack(raw) {
    return {
      id: `soundcloud_${raw.id}`,
      title: raw.title || 'Unknown Title',
      artist: (raw.user && raw.user.username) || 'Unknown Artist',
      albumArt: raw.artwork_url || null,
      streamUrl:
        (raw.media &&
          raw.media.transcodings &&
          raw.media.transcodings.length > 0 &&
          raw.media.transcodings[0].url) ||
        null,
      duration: raw.duration ? Math.round(raw.duration / 1000) : 0,
      source: 'SoundCloud',
    };
  }

  async _fetchWithTimeout(url) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), this.timeoutMs);
    try {
      return await fetch(url, { signal: controller.signal });
    } finally {
      clearTimeout(timer);
    }
  }
}

export default SoundCloudAdapter;