/**
 * GenericRestAdapter.js
 * Fallback adapter for ANY user-added API that returns JSON.
 * Used when a user pastes a custom API key/endpoint that isn't
 * Jamendo or SoundCloud — allows unlimited generic providers.
 *
 * The user (or a config template) supplies a responseMap that tells
 * this adapter how to pull fields out of an arbitrary JSON response,
 * so we don't need bespoke code for every possible API.
 */

import BaseAdapter from './BaseAdapter';

class GenericRestAdapter extends BaseAdapter {
  constructor(config) {
    super(config);
    // searchPath supports a {query} and {apiKey} placeholder, e.g.:
    // "https://example.com/search?q={query}&key={apiKey}"
    this.searchPath = config.searchPath || '';
    // responseMap tells us where to find fields in the JSON result, e.g.:
    // { resultsPath: 'data.items', id: 'id', title: 'name', artist: 'author',
    //   albumArt: 'thumbnail', streamUrl: 'url', duration: 'length' }
    this.responseMap = config.responseMap || {};
  }

  async testConnection() {
    try {
      const url = this._buildUrl('test');
      const response = await this._fetchWithTimeout(url);
      if (!response.ok) {
        return { ok: false, message: `${this.name} responded with status ${response.status}` };
      }
      return { ok: true, message: `${this.name} connected successfully` };
    } catch (err) {
      return { ok: false, message: `${this.name} connection failed: ${err.message}` };
    }
  }

  async search(query) {
    if (!this.isReady()) {
      throw new Error(`${this.name} adapter is not ready: missing API key, URL, or disabled`);
    }
    const url = this._buildUrl(query);
    const response = await this._fetchWithTimeout(url);
    if (!response.ok) {
      throw new Error(`${this.name} search failed with status ${response.status}`);
    }
    const data = await response.json();
    const results = this._getByPath(data, this.responseMap.resultsPath) || [];
    if (!Array.isArray(results)) return [];
    return results.map((item) => this.normalizeTrack(item));
  }

  normalizeTrack(raw) {
    const map = this.responseMap;
    return {
      id: `${this.id}_${this._getByPath(raw, map.id) || Math.random().toString(36).slice(2)}`,
      title: this._getByPath(raw, map.title) || 'Unknown Title',
      artist: this._getByPath(raw, map.artist) || 'Unknown Artist',
      albumArt: this._getByPath(raw, map.albumArt) || null,
      streamUrl: this._getByPath(raw, map.streamUrl) || null,
      duration: this._getByPath(raw, map.duration) || 0,
      source: this.name,
    };
  }

  isReady() {
    return this.enabled && !!this.apiKey && !!this.searchPath;
  }

  _buildUrl(query) {
    return this.searchPath
      .replace('{query}', encodeURIComponent(query))
      .replace('{apiKey}', encodeURIComponent(this.apiKey));
  }

  _getByPath(obj, path) {
    if (!path || !obj) return undefined;
    return path.split('.').reduce((acc, key) => (acc != null ? acc[key] : undefined), obj);
  }

  async _fetchWithTimeout(url) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), this.timeoutMs);
    try {
      return await fetch(url, { signal: controller.signal });
    } finally {
      clearTimeout(timer);
    }
  }
}

export default GenericRestAdapter;