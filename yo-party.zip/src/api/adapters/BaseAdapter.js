/**
 * BaseAdapter.js
 * Abstract base class that every music-provider adapter must implement.
 * Guarantees a uniform interface so the ProviderManager can call any
 * provider interchangeably without knowing its internals.
 */

class BaseAdapter {
  constructor(config) {
    if (new.target === BaseAdapter) {
      throw new Error('BaseAdapter is abstract and cannot be instantiated directly.');
    }
    this.id = config.id;
    this.name = config.name;
    this.apiKey = config.apiKey;
    this.baseUrl = config.baseUrl || '';
    this.enabled = config.enabled !== false;
    this.priority = config.priority || 0;
    this.timeoutMs = config.timeoutMs || 8000;
  }

  /**
   * Must return a normalized array of track objects:
   * { id, title, artist, albumArt, streamUrl, duration, source }
   */
  async search(query) {
    throw new Error(`search() not implemented for adapter: ${this.name}`);
  }

  /**
   * Validates that the current apiKey / credentials actually work.
   * Must return { ok: boolean, message: string }
   */
  async testConnection() {
    throw new Error(`testConnection() not implemented for adapter: ${this.name}`);
  }

  normalizeTrack(raw) {
    throw new Error(`normalizeTrack() not implemented for adapter: ${this.name}`);
  }

  isReady() {
    return this.enabled && !!this.apiKey;
  }
}

export default BaseAdapter;