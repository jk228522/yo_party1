/**
 * AppUI.jsx
 * Root navigation container tying all screens together.
 */

import React, { useState } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import HomeScreen from './HomeScreen';
import ApiKeyManager from '../components/ApiKeyManager';
import { QRGenerate, QRScanner } from '../components/QRShare';
import { View, Text, StyleSheet } from 'react-native';

const Stack = createNativeStackNavigator();

const QRShareScreen = ({ route, navigation }) => {
  const [mode, setMode] = useState(null); // 'host' | 'join'

  if (!mode) {
    return (
      
    );
  }

  if (mode === 'host') {
    return ;
  }

  return (
     {
        navigation.navigate('Home', { joinedSession: payload });
      }}
    />
  );
};

const AppUI = () => {
  return (
    
  );
};

const styles = StyleSheet.create({
  center: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#000000' },
  chooseTitle: { color: '#ffffff', fontSize: 20, marginBottom: 20 },
  chooseOption: { color: '#1DB954', fontSize: 18, marginVertical: 10, fontWeight: '600' },
});

export default AppUI;