/**
 * ApiKeyManager.js
 * The "countless API section" — lets the user add, edit, enable/disable,
 * test, and remove an unlimited number of API providers.
 * Each entry has: name, type (jamendo / soundcloud / generic), API key,
 * optional endpoint + response map for generic APIs, and a Connect/Join button.
 */

import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  FlatList,
  StyleSheet,
  ActivityIndicator,
  Alert,
} from 'react-native';
import providerManager from '../api/ProviderManager';

const PROVIDER_TYPES = [
  { key: 'jamendo', label: 'Jamendo' },
  { key: 'soundcloud', label: 'SoundCloud' },
  { key: 'generic', label: 'Custom / Other' },
];

const ApiKeyManager = () => {
  const [providers, setProviders] = useState([]);
  const [name, setName] = useState('');
  const [type, setType] = useState('jamendo');
  const [apiKey, setApiKey] = useState('');
  const [searchPath, setSearchPath] = useState('');
  const [testingId, setTestingId] = useState(null);

  useEffect(() => {
    (async () => {
      await providerManager.loadFromStorage();
      setProviders([...providerManager.getProviders()]);
    })();
  }, []);

  const refresh = useCallback(() => {
    setProviders([...providerManager.getProviders()]);
  }, []);

  const handleAdd = useCallback(async () => {
    if (!apiKey.trim()) {
      Alert.alert('Missing API key', 'Please enter an API key before connecting.');
      return;
    }
    if (type === 'generic' && !searchPath.trim()) {
      Alert.alert('Missing endpoint', 'Custom APIs need a search URL template, e.g. https://example.com/search?q={query}&key={apiKey}');
      return;
    }

    const cfg = {
      type,
      name: name.trim() || PROVIDER_TYPES.find((p) => p.key === type)?.label || 'Custom API',
      apiKey: apiKey.trim(),
      searchPath: searchPath.trim(),
      enabled: true,
      priority: providerManager.getProviders().length,
    };

    const adapter = await providerManager.addProvider(cfg);
    refresh();
    setName('');
    setApiKey('');
    setSearchPath('');

    // Auto-test the connection right after adding (the "Connect / Join" action)
    setTestingId(adapter.id);
    const result = await providerManager.testProvider(adapter.id);
    setTestingId(null);
    Alert.alert(result.ok ? 'Connected' : 'Connection failed', result.message);
  }, [name, type, apiKey, searchPath, refresh]);

  const handleTest = useCallback(async (id) => {
    setTestingId(id);
    const result = await providerManager.testProvider(id);
    setTestingId(null);
    Alert.alert(result.ok ? 'Connected' : 'Connection failed', result.message);
  }, []);

  const handleToggle = useCallback(
    async (id, enabled) => {
      await providerManager.setEnabled(id, enabled);
      refresh();
    },
    [refresh]
  );

  const handleRemove = useCallback(
    async (id) => {
      await providerManager.removeProvider(id);
      refresh();
    },
    [refresh]
  );

  const renderProvider = ({ item }) => (
    
      
       handleToggle(item.id, !item.enabled)}
        style={[styles.smallButton, item.enabled ? styles.enabledButton : styles.disabledButton]}
      >
        
...