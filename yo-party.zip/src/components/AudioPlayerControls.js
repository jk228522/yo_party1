/**
 * AudioPlayerControls.js
 * Play/pause/seek/volume UI + playback engine bridge (Track Player).
 */

import React, { useState, useEffect, useCallback } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Slider } from 'react-native';
import TrackPlayer, { usePlaybackState, useProgress, State } from 'react-native-track-player';

const AudioPlayerControls = ({ currentTrack, onNext, onPrevious, isHost }) => {
  const playbackState = usePlaybackState();
  const progress = useProgress(500);
  const [isBuffering, setIsBuffering] = useState(false);

  useEffect(() => {
    setIsBuffering(playbackState === State.Buffering || playbackState === State.Connecting);
  }, [playbackState]);

  const togglePlayback = useCallback(async () => {
    const state = await TrackPlayer.getState();
    if (state === State.Playing) {
      await TrackPlayer.pause();
    } else {
      await TrackPlayer.play();
    }
  }, []);

  const handleSeek = useCallback(async (value) => {
    await TrackPlayer.seekTo(value);
  }, []);

  const formatTime = (seconds) => {
    if (!seconds || isNaN(seconds)) return '0:00';
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    

      

      {!isHost && }
    
  );
};

const styles = StyleSheet.create({
  container: { padding: 16, backgroundColor: '#121212', borderRadius: 12 },
  trackTitle: { color: '#ffffff', fontSize: 18, fontWeight: '600' },
  trackArtist: { color: '#aaaaaa', fontSize: 14, marginBottom: 8 },
  slider: { width: '100%', height: 40 },
  timeRow: { flexDirection: 'row', justifyContent: 'space-between' },
  timeText: { color: '#888888', fontSize: 12 },
  controlsRow: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', marginTop: 12 },
  controlButton: { paddingHorizontal: 20, paddingVertical: 10 },
  controlText: { color: '#ffffff', fontSize: 16 },
  playButton: { paddingHorizontal: 28, paddingVertical: 12, backgroundColor: '#1DB954', borderRadius: 30, marginHorizontal: 12 },
  playText: { color: '#000000', fontSize: 16, fontWeight: '700' },
  readOnlyNote: { color: '#666666', fontSize: 11, textAlign: 'center', marginTop: 8 },
});

export default AudioPlayerControls;