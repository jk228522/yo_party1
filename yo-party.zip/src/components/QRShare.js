/**
 * QRShare.js
 * Host: generates a QR code encoding host IP + session token.
 * Client: scans a QR code to auto-join the host's session.
 */

import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import QRCode from 'react-native-qrcode-svg';
import { RNCamera } from 'react-native-camera';

export const QRGenerate = ({ hostIp, sessionToken }) => {
  const payload = JSON.stringify({ hostIp, sessionToken, app: 'YoParty' });

  return (
    
      
    
  );
};

export const QRScanner = ({ onScanned }) => {
  const [scanned, setScanned] = useState(false);

  const handleBarCodeRead = ({ data }) => {
    if (scanned) return;
    try {
      const parsed = JSON.parse(data);
      if (parsed.app !== 'YoParty' || !parsed.hostIp) {
        return; // Ignore QR codes that aren't from this app
      }
      setScanned(true);
      onScanned(parsed);
    } catch (err) {
      console.warn('QRScanner: invalid QR payload', err);
    }
  };

  return (
    
  );
};

const styles = StyleSheet.create({
  container: { alignItems: 'center', padding: 20 },
  label: { color: '#ffffff', fontSize: 16, marginBottom: 16 },
  qrWrapper: { backgroundColor: '#ffffff', padding: 16, borderRadius: 12 },
  subLabel: { color: '#888888', fontSize: 12, marginTop: 12 },
  scannerContainer: { flex: 1 },
  camera: { flex: 1 },
  rescanButton: { position: 'absolute', bottom: 40, alignSelf: 'center', backgroundColor: '#1DB954', padding: 14, borderRadius: 30 },
  rescanText: { color: '#000000', fontWeight: '700' },
});