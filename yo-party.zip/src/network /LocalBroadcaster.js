/**
 * LocalBroadcaster.js
 * UDP-based local network sync for host/client playback.
 * Host broadcasts playback state (SYNC_STATE) on port 8888.
 * Clients listen and calculate offset using local timestamp comparison.
 */

import dgram from 'react-native-udp';

const SYNC_PORT = 8888;
const BROADCAST_ADDRESS = '255.255.255.255';
const SYNC_INTERVAL_MS = 1000;
const DRIFT_THRESHOLD_MS = 150;

class LocalBroadcaster {
  constructor() {
    this.socket = null;
    this.mode = null; // 'host' | 'client' | null
    this.syncTimer = null;
    this.onSyncState = null; // callback(payload) for client mode
    this.hostIp = null;
  }

  // ---------- HOST MODE ----------

  startHost(getPlaybackState) {
    this.mode = 'host';
    this.socket = dgram.createSocket({ type: 'udp4' });

    this.socket.bind(SYNC_PORT, () => {
      this.socket.setBroadcast(true);
    });

    this.syncTimer = setInterval(() => {
      const state = getPlaybackState();
      const payload = {
        type: 'SYNC_STATE',
        timestamp: Date.now(),
        track: state.track,
        position: state.position,
        isPlaying: state.isPlaying,
        hostIp: this.hostIp,
      };
      const message = Buffer.from(JSON.stringify(payload));
      this.socket.send(message, 0, message.length, SYNC_PORT, BROADCAST_ADDRESS, (err) => {
        if (err) console.warn('LocalBroadcaster: broadcast send error', err);
      });
    }, SYNC_INTERVAL_MS);
  }

  stopHost() {
    if (this.syncTimer) clearInterval(this.syncTimer);
    this.syncTimer = null;
    if (this.socket) {
      this.socket.close();
      this.socket = null;
    }
    this.mode = null;
  }

  // ---------- CLIENT MODE ----------

  startClient(hostIp, onSyncState) {
    this.mode = 'client';
    this.hostIp = hostIp;
    this.onSyncState = onSyncState;
    this.socket = dgram.createSocket({ type: 'udp4' });

    this.socket.bind(SYNC_PORT, () => {
      this.socket.setBroadcast(true);
    });

    this.socket.on('message', (msg) => {
      try {
        const payload = JSON.parse(msg.toString());
        if (payload.type !== 'SYNC_STATE') return;

        const localReceiveTime = Date.now();
        const estimatedNetworkDelay = 0; // could be refined with round-trip probing
        const drift = localReceiveTime - payload.timestamp - estimatedNetworkDelay;

        if (this.onSyncState) {
          this.onSyncState({
            ...payload,
            driftMs: drift,
            needsCorrection: Math.abs(drift) > DRIFT_THRESHOLD_MS,
          });
        }
      } catch (err) {
        console.warn('LocalBroadcaster: failed to parse sync packet', err);
      }
    });

    this.socket.on('error', (err) => {
      console.warn('LocalBroadcaster: client socket error', err);
    });
  }

  stopClient() {
    if (this.socket) {
      this.socket.close();
      this.socket = null;
    }
    this.mode = null;
    this.onSyncState = null;
  }

  stop() {
    if (this.mode === 'host') this.stopHost();
    if (this.mode === 'client') this.stopClient();
  }
}

export default LocalBroadcaster;